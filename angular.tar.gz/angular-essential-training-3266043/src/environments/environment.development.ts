export const environment = {
  appFooter: '© Gem Finder, LLC ~ Development Build'
};
