export interface Message {
  id: string;
  message: string;
}
